# IMPORTANT: don't change the "currentScriptVerison" variable name or version format. The Travis script depends on it looking like this
# (major, minor, revision, development)
# example dev version: (1, 2, 3, "beta.4")
# example release version: (2, 3, 4)
currentScriptVersion = (2, 1, 0)
legacyScriptVersion = (2, 0, 2, "legacy")
